"""
ProfitPulse — Stage 1 Financial Analysis Engine

This module performs deterministic calculations only.
The AI layer will be added later; financial truth should come from
code/data, not from an LLM.
"""

from pathlib import Path
import pandas as pd


def load_transactions(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {
        "date", "net_revenue", "profit", "payment_fee",
        "discount", "refund_amount", "refunded", "product"
    }
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    df["date"] = pd.to_datetime(df["date"])
    return df


def summarize(df: pd.DataFrame) -> dict:
    revenue = float(df["net_revenue"].sum())
    profit = float(df["profit"].sum())
    refunds = float(df["refund_amount"].sum())
    fees = float(df["payment_fee"].sum())
    discounts = float(df["discount"].sum())
    orders = int(len(df))
    profit_margin = (profit / revenue * 100) if revenue else 0.0

    return {
        "orders": orders,
        "revenue": round(revenue, 2),
        "profit": round(profit, 2),
        "profit_margin_percent": round(profit_margin, 2),
        "refunds": round(refunds, 2),
        "payment_fees": round(fees, 2),
        "discounts": round(discounts, 2),
    }


def compare_periods(df: pd.DataFrame) -> dict:
    """Compare the first and second half of the available dataset."""
    midpoint = df["date"].min() + (df["date"].max() - df["date"].min()) / 2
    before = df[df["date"] <= midpoint]
    after = df[df["date"] > midpoint]

    a = summarize(before)
    b = summarize(after)

    def pct_change(old, new):
        return round(((new - old) / old) * 100, 2) if old else 0.0

    return {
        "before": a,
        "after": b,
        "change_percent": {
            "revenue": pct_change(a["revenue"], b["revenue"]),
            "profit": pct_change(a["profit"], b["profit"]),
            "refunds": pct_change(a["refunds"], b["refunds"]),
            "payment_fees": pct_change(a["payment_fees"], b["payment_fees"]),
            "discounts": pct_change(a["discounts"], b["discounts"]),
        },
    }


def top_profit_drivers(df: pd.DataFrame) -> list[dict]:
    """Rank product groups by profit contribution."""
    grouped = (
        df.groupby("product")
        .agg(
            revenue=("net_revenue", "sum"),
            profit=("profit", "sum"),
            refunds=("refund_amount", "sum"),
            orders=("transaction_id", "count"),
        )
        .reset_index()
        .sort_values("profit")
    )
    return grouped.to_dict(orient="records")


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    data_path = root / "data" / "transactions.csv"

    df = load_transactions(data_path)
    print("\n=== PROFITPULSE STAGE 1 ===")
    print(summarize(df))
    print("\n=== PERIOD COMPARISON ===")
    print(compare_periods(df))
    print("\n=== LOWEST PROFIT PRODUCT GROUPS ===")
    for row in top_profit_drivers(df):
        print(row)
