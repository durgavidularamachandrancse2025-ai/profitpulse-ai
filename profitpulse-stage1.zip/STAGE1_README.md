# ProfitPulse — Stage 1

Stage 1 contains the deterministic financial foundation:
- synthetic transaction dataset
- profit/revenue/refund/fee calculations
- period comparison
- product-level profit analysis

The AI layer will be added only after the financial engine is working.
